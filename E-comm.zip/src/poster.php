<?php
//     include"config.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<?php require_once 'asset/header.php';?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <style>
        .card-title a
      {
          color:#FFF;
          font-size:1rem;
          font-weight:600;
          margin-left: 1rem;
      }
      .card-title a:hover{
        color:#FFF;
      }
      .card-heading:hover >.card-title a{
        /* color:red; */


      }
      .card-heading:hover{
        background-color:#116530;
        transition: .5s ease-in-out;
      }
      .card-heading
      {
          /* margin-top:10px; */
          background:#28a745;
      }
       .bx{
        float:right;
        font-size:1.5rem;
        transform: translate(1px, 3px);
      }
    </style>
	<?php require_once 'asset/top.php';?>
	<!--<header id="header">-->
		<?php require_once 'asset/nav.php';?>

	<!--</header>-->
     <div class='largeview'>
         <button class="closebtn">X</button>
         <img loading="lazy"/>
         <div class="pic-caption">

         </div>
     </div>

     <div class="page-view">
             <div class= "list">

             </div>
             <div class="content">

             </div>
     </div>
<main id="main">

	  <section id="features" class="features">
      <div class="container" data-aos="fade-up">


    <div class="container">

      <div class="card card-success mb-3">
                    <div class="card-heading  mt-0 rounded" role="tab" id="headingTwenteenSeven">
                        <h4 class="card-title mb-0 p-2" role="button" data-toggle="collapse" data-parent="#accordion" href="#poster" aria-expanded="false" aria-controls="collapseEighteen">
                            <a class="collapsed" >
                              National Conference on Siddha Medicine-2022
                                <i class='bx bx-plus-circle' ></i>

                            </a>
                        </h4>
                    </div>
                    <div id="poster" class="collapse in" role="tabpanel" aria-labelledby="headingTwenteenSeven">
                         <div class="card-body">
                            <div class="card card-success mb-3">
                                <div class="card-heading  mt-0 rounded" role="tab" id="headingTwenteenSeven">
                                    <h4 class="card-title mb-0 p-2" role="button" data-toggle="collapse" data-parent="#accordion" href="#poster_1" aria-expanded="false" aria-controls="collapseEighteen">
                                    <a class="collapsed" >
                                        STUDENTS ACTIVITIES- FIRST YEAR
                                        <i class='bx bx-plus-circle' ></i>

                                    </a>
                                    </h4>
                                </div>
                                <div id="poster_1" class="collapse in" role="tabpanel" aria-labelledby="headingTwenteenSeven">
                                    <div class="card-body">
                                        <table class="table table-responsive table-bordered text-center">
                    <thead >
                    <tr class="table-success">
                        <th colspan="7" >Participation of Students<br>National Conference on Siddha Medicine-2022
                        </th>
                    </tr>
                    <tr class="table-info"><th colspan="7" >
                        STUDENTS ACTIVITIES- FIRST YEAR
                        </th>
                    </tr>
                    <tr class="table-dark text-dark">
                        <th>
                        S.No
                        </th>
                        <th>
                        Mode of Presentation
                        </th>
                        <th>
                        Name of the Corresponding Author
                        </th>
                        <th>
                        Name of the Co Authors
                        </th>
                        <th>
                        Date
                        </th>
                        <th>
                         Title of the Presentation
                        </th>
                        <th>
                        Remarks
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th>
                           1.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            K.P. Ajitha
                        </td>

                         <td>
                            A. Kaviyasree, B. Nandhini
                        </td>
                        <td>
                            16.12.2022
                        </td>
                        <td>
                            A Review article on Siddhar's Manimagudam (Muppu)
                        </td>
                        <td>
                        </td>
                    </tr>
                </tbody>
            </table>
    </div>
    </div>


        </div>

        <div class="card card-success mb-3">
                                <div class="card-heading  mt-0 rounded" role="tab" id="headingTwenteenSeven">
                                    <h4 class="card-title mb-0 p-2" role="button" data-toggle="collapse" data-parent="#accordion" href="#poster_2" aria-expanded="false" aria-controls="collapseEighteen">
                                    <a class="collapsed" >
                                        STUDENTS ACTIVITIES- SECOND YEAR
                                        <i class='bx bx-plus-circle' ></i>

                                    </a>
                                    </h4>
                                </div>
                                <div id="poster_2" class="collapse in" role="tabpanel" aria-labelledby="headingTwenteenSeven">
                                    <div class="card-body">
            <table class="table table-responsive table-bordered text-center">
                <thead >
                    <tr class="table-success">
                        <th colspan="7" >Participation of Students<br>National Conference on Siddha Medicine-2022
                        </th>
                    </tr>
                    <tr class="table-info"><th colspan="7" >
                        STUDENTS ACTIVITIES- SECOND YEAR
                        </th>
                    </tr>
                    <tr class="table-dark text-dark">
                        <th>
                        S.No
                        </th>
                        <th>
                        Mode of Presentation
                        </th>
                        <th>
                        Name of the Corresponding Author
                        </th>
                        <th>
                        Name of the Co Authors
                        </th>
                        <th>
                        Date
                        </th>
                        <th>
                         Title of the Presentation
                        </th>
                        <th>
                        Remarks
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th>
                           1.
                        </th>
                        <td>
                            Oral
                        </td>
                        <td>
                            R.Bharathi
                        </td>

                         <td>
                            Dr.G.Dineshraman
                        </td>
                        <td>
                            16-12-2022
                        </td>
                        <td>
                           Menorrhagia
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           2.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                           K.Manimozhi
                        </td>

                         <td>
                            C.Jayakrishnan
                        </td>
                        <td>
                            15-12-2022
                        </td>
                        <td>
                           Cancer
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           3.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            R.Prithivirajan
                        </td>

                         <td>
                            S.Tharanidharan
                        </td>
                        <td>
                            15-12-2022
                        </td>
                        <td>
                           Eczema
                        </td>
                        <td>
                        </td>
                    </tr>
                </tbody>
            </table>
                                    </div>
                                </div>
        </div>

        <div class="card card-success mb-3">
                                <div class="card-heading  mt-0 rounded" role="tab" id="headingTwenteenSeven">
                                    <h4 class="card-title mb-0 p-2" role="button" data-toggle="collapse" data-parent="#accordion" href="#poster_3" aria-expanded="false" aria-controls="collapseEighteen">
                                    <a class="collapsed" >
                                        STUDENTS ACTIVITIES- THIRD YEAR
                                        <i class='bx bx-plus-circle' ></i>

                                    </a>
                                    </h4>
                                </div>
                                <div id="poster_3" class="collapse in" role="tabpanel" aria-labelledby="headingTwenteenSeven">
                                    <div class="card-body">
        <table class="table table-responsive table-bordered text-center">
                <thead >
                    <tr class="table-success">
                        <th colspan="7" >Participation of Students<br>National Conference on Siddha Medicine-2022
                        </th>
                    </tr>
                    <tr class="table-info"><th colspan="7" >
                        STUDENTS ACTIVITIES- THIRD YEAR
                        </th>
                    </tr>
                    <tr class="table-dark text-dark">
                        <th>
                        S.No
                        </th>
                        <th>
                        Mode of Presentation
                        </th>
                        <th>
                        Name of the Corresponding Author
                        </th>
                        <th>
                        Name of the Co Authors
                        </th>
                        <th>
                        Date
                        </th>
                        <th>
                         Title of the Presentation
                        </th>
                        <th>
                        Remarks
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th>
                           1.
                        </th>
                        <td>
                            Oral
                        </td>
                        <td>
                            Subhashree sukumar
                        </td>

                         <td>
                            A.Deepa priya
                        </td>
                        <td>
                            16.12.2022
                        </td>
                        <td>
                           Management of UTI-Sadaveri Leghiyam
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           2.
                        </th>
                        <td>
                            Oral
                        </td>
                        <td>
                            T. Sakthimozhi
                        </td>

                         <td>

                        </td>
                        <td>
                            16.12.2022
                        </td>
                        <td>
                           Maruthondri -Regulation of pitham disease
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           3.
                        </th>
                        <td>
                            Oral
                        </td>
                        <td>
                            C.Raghul
                        </td>

                         <td>

                        </td>
                        <td>
                            16.12.2022
                        </td>
                        <td>
                           Comparison of Pillai Tamil Paruvangal (Milestones)
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           4.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            S.Sakthidevi
                        </td>

                         <td>
                            R.Priya
                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Review of Siddha medicine to treat Ulcerative colitis
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           5.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            U.Vidhya Sri
                        </td>

                         <td>

                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Effectiveness of Unripo Pappaya for Healing of Foot Ulcer
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           6.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            V.Kanmani
                        </td>

                         <td>

                        </td>
                        <td>
                            16.12.2022
                        </td>
                        <td>
                           Review of Vetiver visiri on Stress management
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           7.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            B.Santhiya: R.Sivatharani
                        </td>

                         <td>

                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Literature review of role of Fasting in fever
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           8.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            J.Anusiya
                        </td>

                         <td>
                            A.J. Sheeba
                        </td>
                        <td>
                            16.12.2022
                        </td>
                        <td>
                           Role of Panchaboodham and arusuvai in the treatment of Siddha
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           9.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            V.Swetha
                        </td>

                         <td>
                            S.M.Anisha
                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Etiology of hypertension on Siddha literature review
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           10.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            D.Abigeetha
                        </td>

                         <td>
                           K.Atchaya
                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Effectiveness of polyherbal formulation of Jaathikai chooranam for migrane
                        </td>
                        <td>
                        </td>
                    </tr>
                </tbody>
            </table>
    </div>
    </div>
        </div>
           
        <div class="card card-success mb-3">
                                <div class="card-heading  mt-0 rounded" role="tab" id="headingTwenteenSeven">
                                    <h4 class="card-title mb-0 p-2" role="button" data-toggle="collapse" data-parent="#accordion" href="#poster_4" aria-expanded="false" aria-controls="collapseEighteen">
                                    <a class="collapsed" >
                                        STUDENTS ACTIVITIES- FINAL YEAR
                                        <i class='bx bx-plus-circle' ></i>

                                    </a>
                                    </h4>
                                </div>
                                <div id="poster_4" class="collapse in" role="tabpanel" aria-labelledby="headingTwenteenSeven">
                                    <div class="card-body">
        <table class="table table-responsive table-bordered text-center">
                <thead >
                    <tr class="table-success">
                        <th colspan="7" >Participation of Students<br>National Conference on Siddha Medicine-2022
                        </th>
                    </tr>
                    <tr class="table-info"><th colspan="7" >
                        STUDENTS ACTIVITIES- FINAL YEAR
                        </th>
                    </tr>
                    <tr class="table-dark text-dark">
                        <th>
                        S.No
                        </th>
                        <th>
                        Mode of Presentation
                        </th>
                        <th>
                        Name of the Corresponding Author
                        </th>
                        <th>
                        Name of the Co Authors
                        </th>
                        <th>
                        Date
                        </th>
                        <th>
                         Title of the Presentation
                        </th>
                        <th>
                        Remarks
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th>
                           1.
                        </th>
                        <td>
                            Oral
                        </td>
                        <td>
                            G.Banumathi
                        </td>

                         <td>

                        </td>
                        <td>
                            16.12.2022
                        </td>
                        <td>
                           Management of cerebral Palsy through Siddha system
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           2.
                        </th>
                        <td>
                            Oral
                        </td>
                        <td>
                            C.Sujitha
                        </td>

                         <td>

                        </td>
                        <td>
                            16.12.2022
                        </td>
                        <td>
                           Internal and External medicine for Peripheral neuritis
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           3.
                        </th>
                        <td>
                            Oral
                        </td>
                        <td>
                            G.V.Raghava Yuvashree
                        </td>

                         <td>

                        </td>
                        <td>
                            16.12.2022
                        </td>
                        <td>
                           Therapeutic approach of Mukkootu ennai & Thirumeni thailam for manipulation of various Varma points
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           4.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            S.Abinaya
                        </td>

                         <td>
                            K.Hemalatha
                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Siddha medicine for Pediatrics- Maantham
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           5.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            K.Hemalatha
                        </td>

                         <td>
                            S.Abinaya
                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Siddha medicine for Parkinson's disease
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           6.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            S.Harini
                        </td>

                         <td>

                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Treatment  Perspective of Cancer in Siddha system
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           7.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                           S.Jaisri Vishnu Priyanka
                        </td>

                         <td>
                            S.Akilandeswari
                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Lotus and Pregnancy
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           8.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            A.I.Dillirani
                        </td>

                         <td>
                            G.Banumathi
                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Perspective treatment for Azoospermia
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           9.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            P.V.Thirukumaran
                        </td>

                         <td>

                        </td>
                        <td>
                            16.12.2022
                        </td>
                        <td>
                           Siddha Maruthuvathil ulla Peru marunthu- Gowri Sinthamani Chenduram
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           10.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            R.Kaviyasri
                        </td>

                         <td>

                        </td>
                        <td>
                            16.12.2022
                        </td>
                        <td>
                           Fundamental principles of Naadi in Varmam
                        </td>
                        <td>
                        </td>
                    </tr>


                    <tr>
                        <th>
                           11.
                        </th>
                        <td>
                            Oral
                        </td>
                        <td>
                            S.Meenaloshini
                        </td>

                         <td>

                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           A review article on the treatment of Psychiatric disorder ( Application of Thoothuvalai
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           12.
                        </th>
                        <td>
                            Oral
                        </td>
                        <td>
                            C.Sujitha
                        </td>

                         <td>
                            S.Senthilkumar
                        </td>
                        <td>
                            16.12.2022
                        </td>
                        <td>
                           Sivanuraitha Sivanar Amirtham
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           13.
                        </th>
                        <td>
                            Oral
                        </td>
                        <td>
                            V.Harinibala
                        </td>

                         <td>
                            E.Bharathi: R.Ramya
                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Siddha treatment for Vulvovaginal candidiasis
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           14.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            A.Anudharshini
                        </td>

                         <td>
                            A.Anbarasi
                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Fundamental principles in Siddha Fasting (Langanam)
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           15.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            T.Vidhya
                        </td>

                         <td>
                            Mathiyoli: M.Manjula: T.Suruthi
                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                          The Role of Siddha system of medicine in treating musculoskeletal disorder
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           16.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            K.Abinaya
                        </td>

                         <td>
                            R.Sowmiya
                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Siddha system of medicine inthe menorrhagia
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           17.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            R.Shalini
                        </td>

                         <td>
                            N.Sahana
                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Siddha treatment for lowback pain in menopausal women
                        </td>
                        <td>
                        </td>
                    </tr>
                    <tr>
                        <th>
                           18.
                        </th>
                        <td>
                            Poster
                        </td>
                        <td>
                            N.Sahana
                        </td>

                         <td>
                            R.Shalini
                        </td>
                        <td>
                            15.12.2022
                        </td>
                        <td>
                           Siddha treatment for karukuli vatham (Adenomyosis)
                        </td>
                        <td>
                        </td>
                    </tr>
                </tbody>
            </table>
    </div>
    </div>
        </div>

        <div class="card card-success mb-3">
                                <div class="card-heading  mt-0 rounded" role="tab" id="headingTwenteenSeven">
                                    <h4 class="card-title mb-0 p-2" role="button" data-toggle="collapse" data-parent="#accordion" href="#poster_5" aria-expanded="false" aria-controls="collapseEighteen">
                                    <a class="collapsed" >
                                        STUDENTS ACTIVITIES- ICCR
                                        <i class='bx bx-plus-circle' ></i>

                                    </a>
                                    </h4>
                                </div>
                                <div id="poster_5" class="collapse in" role="tabpanel" aria-labelledby="headingTwenteenSeven">
                                    <div class="card-body">
             <table class="table table-responsive table-bordered text-center">
                <thead >
                    <tr class="table-success">
                        <th colspan="7" >Participation of Students<br>National Conference on Siddha Medicine-2022
                        </th>
                    </tr>
                    <tr class="table-info"><th colspan="7" >
                        STUDENTS ACTIVITIES- CRRI
                        </th>
                    </tr>
                    <tr class="table-dark text-dark">
                        <th>
                        S.No
                        </th>
                        <th>
                        Mode of Presentation
                        </th>
                        <th>
                        Name of the Corresponding Author
                        </th>
                        <th>
                        Name of the Co Authors
                        </th>
                        <th>
                        Date
                        </th>
                        <th>
                         Title of the Presentation
                        </th>
                        <th>
                        Remarks
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th>
                           1.
                        </th>
                        <td>
                            Oral
                        </td>
                        <td>
                            B.Priyadharshini
                        </td>

                         <td>

                        </td>
                        <td>
                            16.12.2022
                        </td>
                        <td>
                           Immune Booster in Pumpkin seeds
                        </td>
                        <td>
                        </td>
                    </tr>
                    </tbody>
                    </table>
                                    </div>
                                </div>
        </div>
                         </div>
                    </div>
      </div>
    </div>
      </div>
      </section>

        <section id="recent-works">
	 	  <div class="container">
			<div class="center wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;">
			</div>
    </div>


	<div class="row">
			    <div class="container">
    <!--<div class="section-title">-->
    <!--      <h2>COVID APPROPRIATE BEHAVIOR Posters prepared by the students</h2>-->
    <!--    </div>-->
      <div class="card card-success mb-3">
                    <div class="card-heading  mt-0 rounded" role="tab" id="headingTwenteenSeven">
                        <h4 class="card-title mb-0 p-2" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapsetwenteenSeven" aria-expanded="false" aria-controls="collapseEighteen">
                            <a class="collapsed" >
                               COVID APPROPRIATE BEHAVIOR Posters prepared by the students
                                <i class='bx bx-plus-circle' ></i>

                            </a>
                        </h4>
                    </div>
                    <div id="collapsetwenteenSeven" class="collapse in" role="tabpanel" aria-labelledby="headingTwenteenSeven">
    <div class="row">
        <div class="col-md-12">
            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                <div class="panel panel-default">
                    <div id="collapseOne" class="" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            <?php
for ($i = 0; $i < 60; $i++) {
    ?>
                                <div class="col-md-4 col-sm-8 col-xs-12" style="margin-top: 30px;">
                                	<a rel="gallery" class="fancybox-buttons" data-fancybox-group="button" href="pdf_to_jpeg/jpeg/PICS-(<?php echo $i; ?>).jpg">
					                   <div class="product-zoom">
					                     <img loading="lazy" src="pdf_to_jpeg/jpeg/PICS-(<?php echo $i; ?>).jpg" width="360" height="240">
					                   </div>
					                 </a>

                                </div>
                            <?php
}
?>
                        </div>
                    </div>
                </div>



                    	</div>
                    </div>
                </div>
                </div>
                </div>
<!--------------------->
<!---------Need of exploratory integrated research in the time of pandemic------------>

		   </div>
        </div>
    </div>
</div>
</div>
		</div>

                </div>
                </div><!--/.col-md-3-->
            </div>
        </div>
    </section><!--/#bottom-->


	<?php require_once 'asset/footer.php';?>
		<style>
		 .panel .fancybox-buttons
    {
        position:relative;
    }
			.panel-title a
			{
			    color:#555500;
			}
			.panel-heading
			{
			    margin-top:10px;
			}
			.panel-body div
			{
			    float:left;
			}
			.panel
			{
			    float:top;
			}
			.panel-collapse
			{
                width: 100%;
                height: 100%;
                overflow: hidden;
			}
			}
			.panel-body
			{
    			width: 100%;
                height: 100%;
                overflow-y: scroll;
                padding: 17px;
                box-sizing: content-box;
			}
			.largeview
			{
			    position:fixed;
			    background-repeat:none !important;
			    height:75%;
			    width:75%;
			    left:10%;
			    top:10%;
			    display:none;
			    z-index:100;
			    padding:2px;
			    margin:2px;
			    border:2px solid #555;
			    transition-duration:1s;
			}
			.closebtn
			{
                float: right;
			    position:relative;
			    border:solid #000055;
			    border-radius:33%;


			}
			.pic-caption
			{
			    position:relative;
			    color:#ffffff;
			    margin-top:365px;
			    transition-duration:500ms;
			    background-color:rgba(0,0,0,0);
			    height:0px;
			    font-size:0px;
			}

			.largeview:hover>.pic-caption
			{
			    background-color:rgba(2,2,2,0.5);
			    height:50px;
			    font-size:25px;
			}

		</style>
		<script>
		$(document).ready(function(){
		    $('#main').click(function(e){
		     //   $('.closebtn').click();
		    });
		    $('.closebtn').click(function(e){
		        $(".largeview").attr("style","display:none");
		    });
		    $('.fancybox-buttons').click(function(e){
		        e.preventDefault();

		        var image=$(this).attr('href');
		        var caption=$(this).attr('alt');

		        image='background-repeat:no-repeat;background-size: 100% 100%;display:block;'+"background-image:url('./"+image+"');";
		        $(".largeview").attr("style",image);
		        $('.pic-caption').html(caption);

		    });
		});
		</script>
	</body>
    </html>